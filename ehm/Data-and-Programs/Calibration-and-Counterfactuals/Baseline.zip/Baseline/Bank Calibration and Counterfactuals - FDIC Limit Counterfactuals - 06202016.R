##############################################################################
##############################################################################
######                                                                  ######
######            Deposit Compeition and Financial Fragility            ###### 
######                  Optimal Capital Req: Baseline                   ######
######                          06/20/2016                              ######
######           By Mark Egan, Ali Hortacsu and Gregor Matvos           ######
######                                                                  ######
##############################################################################
##############################################################################

### Contents ###
# 1. Load files and data 
# 2. Create functions for searching for equilibria
# 3. FDIC Insurance Limit Change - Create Table 5
# 4. Risk Limit Change  - Create Table A3


##############################################################################1

######################################
####    1. Load Files and Data    ####
######################################

############################
### 1(a) Import Raw Data ###
############################
.libPaths( c( .libPaths(), "H:/Rpackages") )
library(doSNOW)
library(foreach)
library(nleqslv)
rm(list = ls())
setwd("H:/My Documents/Research/Deposit Competition/R - Files/AER Version/Baseline")
date<- "31mar2008"
df.full<- read.csv("H:/My Documents/Research/Deposit Competition/R - Files/calibration params 06-20-2016.csv")
#df.full$cap.i<- df.full$cmt1y+.05
df.full$cap.i<- 100
df.full$cap.u<- 100
df<-df.full[df.full$date==date& (!is.na(df.full$b)),]
df$hazard<- df$hazard
################################
### 1(b) Calibrate the Model ###
################################
# The inputed dataframe cointains the calibrated parameters. This section recalibrates the model
# to account for rounding errors when the data is imported
df$ins_share=df$ins_dep/df$M_i
df$unins_share=df$unins_dep/df$M_u
df$sd = (((1+df$int_rate)/(df$ins_dep+df$unins_dep))*(df$b+df$ins_dep*(df$unins_rate+1/(df$alpha_unins*(1-df$unins_share))-1/(df$alpha_ins*(1-df$ins_share)))+df$unins_dep*df$unins_rate)-(1+df$int_rate)*(1/(df$alpha_unins*(1-df$unins_share))+df$unins_rate))/(dnorm(qnorm(df$hazard))+qnorm(df$hazard)*(df$hazard+df$int_rate)-(1+df$int_rate)*dnorm(qnorm(df$hazard))/(1-df$hazard))
df$mu = 1/(df$alpha_unins*(1-df$unins_share))+df$unins_rate-df$sd*dnorm(qnorm(df$hazard))/(1-df$hazard)
df$c = -1/((1-df$ins_share)*df$alpha_ins) + df$mu + df$sd*dnorm(qnorm(df$hazard))/(1-df$hazard)-df$ins_rate

######################################
### 1(c) Create Relevant Variables ###
######################################
df<-df[df$unins_share>0.03,]
kappa<- df$int_rate*0
df$o_unins_share<- 1-sum(df$unins_share)
df$o_ins_share<- 1-sum(df$ins_share)
p.i<- df$ins_rate
p.u<- df$unins_rate
gamma<- df$gamma
delta.u<-df$delta_u
delta.i<-df$delta_i
alpha.u<-df$alpha_unins
alpha.i<-df$alpha_ins
hazard<-df$hazard
#This calculates the unobserved error term from the demand regression that gives us the observed market share
error.u<- log(df$unins_share)-log(df$o_unins_share[1])-(alpha.u*p.u+delta.u+hazard*gamma)
error.i<- log(df$ins_share)-log(df$o_ins_share[1])-(alpha.i*p.i+delta.i)
outside.u<- (1/df$o_unins_share[1]-sum(exp(alpha.u*p.u+delta.u+hazard*gamma+error.u)))
outside.i<- (1/df$o_ins_share[1]-sum(exp(alpha.i*p.i+delta.i+error.i)))
mu<-df$mu
sd<-df$sd
r<-df$int_rate
M.u<- df$M_u
M.i<- df$M_i
b<-df$b
c<-df$c
cap.i<- df$cap.i[1]
cap.u<- df$cap.u[1]

##############################################################################

###########################################################
####    2. Create Functions for Finding Equilibrium    ####
###########################################################

##########################################################
### 2(a) Caluclate Equilibrium  First Order Conditions ###
##########################################################
# This function checks and reports the 15 first order conditions for the banks
fn.eqFOC <-function(params,mu,sd,gamma,delta.u,delta.i,alpha.u,alpha.i,b,M.u,M.i,error.i,error.u,c,outside.u, outside.i,r,cap.i,cap.u,k,r.eq){
  p.u <- params[1:5]
  p.i <- params[6:10]
  p.i[p.i>cap.i]<-cap.i
  p.u[p.u>cap.u]<-cap.u
  e.hazard<-params[11:15]
  numer.u<-exp(alpha.u*p.u+delta.u+e.hazard*gamma+error.u)
  denom.u<- sum(numer.u)+outside.u
  s.u<- numer.u/denom.u
  numer.i<-exp(alpha.i*p.i+delta.i +error.i)
  denom.i<- sum(numer.i)+outside.i
  s.i<- numer.i/denom.i
  eq.u <-1-alpha.u*(mu*(1+k)+(1+k)*sd*dnorm(qnorm(e.hazard))/(1-e.hazard)-p.u-k*r.eq-k*e.hazard/(1-e.hazard))*(1-s.u)
  eq.i <-1-alpha.i*(mu*(1+k)+(1+k)*sd*dnorm(qnorm(e.hazard))/(1-e.hazard)-p.i-c-k*r.eq-k*e.hazard/(1-e.hazard))*(1-s.i)
  
  #Check for corner solutions
  eq.i[p.i==cap.i]<- eq.i[p.i==cap.i]*(eq.i[p.i==cap.i]>0)
  eq.u[p.u==cap.u]<- eq.u[p.u==cap.u]*(eq.u[p.u==cap.u]>0)
  r.bar<- qnorm(e.hazard)*sd+mu
  lhs<-((1+r)/(s.u*M.u+M.i*s.i+b))*(b*(1-k)-s.u*M.u*(r.bar-p.u+k)-s.i*M.i*(r.bar-c-p.i+k)-k*(s.u*M.u+s.i*M.i+b)*(r.bar-r.eq))
  rhs<- -k+(k+(s.u*M.u+M.i*s.i)/(s.u*M.u+M.i*s.i+b))*(sd*dnorm(qnorm(e.hazard))-sd*qnorm(e.hazard)*(1-e.hazard))
  eq.haz<- lhs-rhs 
  res<- cbind(t(eq.u),t(eq.i),matrix(eq.haz,ncol=5,nrow=1))
  return(res)
}

#############################
### 2(b) Find Equilibrium ###
#############################
# This uses the function nleqslv to find equilibria
fn.findEq<- function(params,mu,sd,gamma,delta.u,delta.i,alpha.u,alpha.i,b,M.u,M.i,error.i,error.u,c,outside.u,outside.i,r,cap.i,cap.u,k,r.eq){
  find.eq<- nleqslv(params,fn.eqFOC,method="Newton",control=list(maxit=5000,xtol=1e-10,ftol=1e-10),mu=mu,sd=sd,gamma=gamma,delta.u=delta.u,delta.i=delta.i,alpha.u=alpha.u,alpha.i=alpha.i,b=b,M.u=M.u,M.i=M.i,error.i=error.i,error.u=error.u,c=c,outside.u=outside.u,outside.i=outside.i,r=r,cap.i=cap.i,cap.u=cap.u,k=k,r.eq=r.eq)    
  res<- find.eq$x
  r1<- res[1:5]
  r2<- res[6:10]
  r1[r1>cap.u]<-cap.u
  r2[r2>cap.i]<-cap.i
  res[1:5]<-r1
  res[6:10]<-r2
  if(find.eq$termcd!=1){
    res<- res*0
  }
  return(t(cbind(t(res),t(find.eq$f))))
}


test<-fn.findEq(t(c(p.u,p.i,hazard)),mu,sd,gamma,delta.u,delta.i,alpha.u,alpha.i,b,M.u,M.i,error.i,error.u,c,outside.u,outside.i,r,cap.i,cap.u,kappa,r)

##############################################################################1

#############################################################
####    3. FDIC Insurance Limit Change - Create Table 5  ####
#############################################################

####################################################################################
### Method 1: Old Uninsured Deposits are Treated as Insured Deposits  (Table 6B) ###
####################################################################################
M.u2<- M.u *.99
M.i2<- M.i +M.u*.01
cf.fdic.2<- fn.findEq(cbind(p.u,p.i,hazard),mu,sd,gamma,delta.u,delta.i,alpha.u,alpha.i,b,M.u2,M.i2,error.i,error.u,c,outside.u,outside.i,r,100,100,kappa,r)
hazard.c1<- cf.fdic.2[11:15]
numer.i1<-exp(alpha.i*(cf.fdic.2[6:10])+delta.i +error.i)
denom.i1<- sum(numer.i1)+outside.i
share.i1<-numer.i1/denom.i1
cost.1<- (M.i2*share.i1*hazard.c1*(1-0.6) - M.i*df$ins_share*hazard*(1-0.6))/1000 
fdic.res<-cbind(paste(df$shortname),round(hazard.c1,4),cost.1)

###################################################################################
### Method 2: Old Uninsured Deposits are Treated as New Deposit Type (Table 6A) ###
###################################################################################
# This function checks and reports the 20 first order conditions for the banks.
# Banks now set a new deposit rate for the newly insured deposits
fn.eqFOC.FDIC <- function(params,mu,sd,gamma,delta.u,delta.i,alpha.u,alpha.i,b,M.u,M.ui,M.i,error.i,error.u,c,outside.u, outside.i,r,cap.i,cap.u){
  p.u <- params[1:5]
  p.i <- params[6:10]
  p.ui <- params[16:20]
  p.i[p.i>cap.i]<-cap.i
  p.u[p.u>cap.u]<-cap.u
  e.hazard<-params[11:15]
  numer.u<-exp(alpha.u*p.u+delta.u+e.hazard*gamma+error.u)
  denom.u<- sum(numer.u)+outside.u
  s.u<- numer.u/denom.u
  numer.ui<-exp(alpha.u*p.ui+delta.u+error.u)
  denom.ui<- sum(numer.ui)+outside.u
  s.ui<- numer.ui/denom.ui
  numer.i<-exp(alpha.i*p.i+delta.i +error.i)
  denom.i<- sum(numer.i)+outside.i
  s.i<- numer.i/denom.i
  eq.u <-1-alpha.u*(mu+sd*dnorm(qnorm(e.hazard))/(1-e.hazard)-p.u)*(1-s.u)
  eq.ui <-1-alpha.u*(mu+sd*dnorm(qnorm(e.hazard))/(1-e.hazard)-p.ui)*(1-s.ui)
  eq.i <-1-alpha.i*(mu+sd*dnorm(qnorm(e.hazard))/(1-e.hazard)-p.i-c)*(1-s.i)
  eq.i[p.i==cap.i]<- eq.i[p.i==cap.i]*(eq.i[p.i==cap.i]>0)
  eq.u[p.u==cap.u]<- eq.u[p.u==cap.u]*(eq.u[p.u==cap.u]>0)
  r.bar<- qnorm(e.hazard)*sd+mu
  lhs<-((1+r)/(s.u*M.u+s.i*M.i+ s.ui*M.ui))*(b-s.u*M.u*(r.bar-p.u)-s.i*M.i*(r.bar-c-p.i)-s.ui*M.ui*(r.bar-p.ui))
  rhs<-sd*dnorm(qnorm(e.hazard))-sd*qnorm(e.hazard)*(1-e.hazard)
  eq.haz<- lhs-rhs 
  res<- cbind(t(eq.u),t(eq.i),t(eq.ui),matrix(eq.haz,ncol=5,nrow=1))
  return(res)
}
# This uses the function nleqslv to find equilibria
fn.findEq.FDIC<- function(params,mu,sd,gamma,delta.u,delta.i,alpha.u,alpha.i,b,M.u,M.ui,M.i,error.i,error.u,c,outside.u,outside.i,r,cap.i,cap.u){
  find.eq<- nleqslv(params,fn.eqFOC.FDIC,control=list(maxit=5000),mu=mu,sd=sd,gamma=gamma,delta.u=delta.u,delta.i=delta.i,alpha.u=alpha.u,alpha.i=alpha.i,b=b,M.u=M.u,M.ui=M.ui,M.i=M.i,error.i=error.i,error.u=error.u,c=c,outside.u=outside.u,outside.i=outside.i,r=r,cap.i=cap.i,cap.u=cap.u)    
  res<- find.eq$x
  r1<- res[1:5]
  r2<- res[6:10]
  r3<- res[11:15]
  r1[r1>cap.u]<-cap.u
  r2[r2>cap.i]<-cap.i
  res[1:5]<-r1
  res[6:10]<-r2
  if(find.eq$termcd!=1){
    res<- res*0
  }
  return(res)
}
params<-t(cbind(t(p.u),t(p.i),t(hazard),t(p.u)))
cf.fdic.2<- nleqslv(params,fn.eqFOC.FDIC,control=list(maxit=5000),mu=mu,sd=sd,gamma=gamma,delta.u=delta.u,delta.i=delta.i,alpha.u=alpha.u,alpha.i=alpha.i,b=b,M.u=M.u*.99,M.ui=M.u*.01,M.i=M.i,error.i=error.i,error.u=error.u,c=c,outside.u=outside.u,outside.i=outside.i,r=r,cap.i=cap.i,cap.u=cap.u)    
hazard.c2<- cf.fdic.2$x[11:15]
numer.i2<-exp(alpha.i*(cf.fdic.2$x[6:10])+delta.i +error.i)
denom.i2<- sum(numer.i2)+outside.i
share.i2<-numer.i2/denom.i2
numer.u2<-exp(alpha.u*(cf.fdic.2$x[16:20])+delta.u +error.u)
denom.u2<- sum(numer.u2)+outside.u
share.u2<-numer.u2/denom.u2
cost.2<- ((M.i*share.i2+M.u*.01*share.u2)*hazard.c2*(1-0.6) - M.i*df$ins_share*hazard*(1-0.6))/1000 
fdic.res.2<-cbind(paste(df$shortname),round(hazard.c2,4),cost.2)

##############################################################################

#######################################################
####    4. Risk Limit Change  - Create Table A3    ####
#######################################################
# Cap the standard deviation returns
sd2<-sd
sd2[sd>0.12]<-0.12
cf.sd<- fn.findEq(cbind(p.u,p.i,hazard),mu,sd2,gamma,delta.u,delta.i,alpha.u,alpha.i,b,M.u,M.i,error.i,error.u,c,outside.u,outside.i,r,100,100,kappa,r)
hazard.sd<- cf.sd[11:15]
