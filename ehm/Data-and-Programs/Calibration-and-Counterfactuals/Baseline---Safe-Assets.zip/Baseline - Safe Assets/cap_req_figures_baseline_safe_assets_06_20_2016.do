// INSTRUCTIONS:
	//	1. Run the R-file for the CR counterfactual
	//	2. Verify that the files "5 bank eqm CR W-CAP WLFR for 31mar2009 with cr = `k' and rk = 0.05 for N=9"
	//	   were created in the corrsponding, for `k' = {0,0.01,...,0.5}
	//	3. Update the CD line below
	//	4. Run the do-file
	//	5. It will generate the figures in the paper, and an excel file that collects the relevant results

// Set directory	
	clear all
	set more off
	cd "H:\My Documents\Research\Deposit Competition\R - Files\AER Version\Baseline - Safe Assets"

// Prepare grid	
	 global grid  0.01 0.02 0.03 0.04 0.05 0.06 0.07 0.08 0.09 0.1 0.11 0.12 0.13 0.14 0.15 0.16 0.17 0.18 0.19 0.2 0.21 0.22 0.23 0.24 0.25 0.26 0.27 0.28 0.29 0.3 0.31 0.32 0.33 0.34 0.35 0.36 0.37 0.38 0.39 0.4 0.41 0.42 0.43 0.44 0.45 0.46 0.47 0.48 0.49 0.5 
	// global grid  0.02 0.04 0.06 0.08 0.1 0.12 0.14 0.16 0.18 0.2 0.22 0.24 0.26 0.28 0.3 0.32 0.34 0.36 0.38 0.4 0.42 0.44 0.46 0.48 0.5
	//global grid  0.1 0.2 0.3 0.4 0.5
	

// 1. W-CAP

// Prepare data for plots using results' files	

	foreach k in 0 $grid {

	// Import data
		import delimited "Tables CR/5 bank eqm W-CR WO-CAP 2nd N=5 for 31mar2008 with cr=`k'.csv", clear
				  
	// Some renaming
		rename v1 id_var
		rename v2 obs
		order id_var

	// Transpose
		xpose, clear varname
		order _varname
		drop if _varname == "id_var"
		egen zero_eq = rowtotal(v1-v15)
		drop if zero_eq == 0
		drop zero_eq

		rename v1 ir_i_1
		rename v2 ir_i_2
		rename v3 ir_i_3
		rename v4 ir_i_4
		rename v5 ir_i_5

		rename v6 ir_u_1
		rename v7 ir_u_2
		rename v8 ir_u_3
		rename v9 ir_u_4
		rename v10 ir_u_5

		rename v11 dp_1
		rename v12 dp_2
		rename v13 dp_3
		rename v14 dp_4
		rename v15 dp_5

		rename v16 ms_i_1
		rename v17 ms_i_2
		rename v18 ms_i_3
		rename v19 ms_i_4
		rename v20 ms_i_5
		rename v21 ms_i_inside

		rename v22 ms_u_1
		rename v23 ms_u_2
		rename v24 ms_u_3
		rename v25 ms_u_4
		rename v26 ms_u_5
		rename v27 ms_u_inside

		rename v28 wc_tot
		rename v29 aev
		rename v30 fdic_pay
		rename v31 bc_10
		rename v32 bc_20
		rename v33 w_00
		rename v34 w_10
		rename v35 w_20
		rename v36 cap_posted
		
		rename _varname id_eq
		gen id = _n - 1
		tostring id, replace
		replace id_eq = id
		drop id
		destring id_eq, replace

		gen cr = `k'
		order cr
		save "Tables CR/cont_kappa_`k'_W-CR_w.dta", replace
	}

// Append all results across CR
	use "Tables CR/cont_kappa_0_W-CR_w.dta", clear
	foreach k in $grid {
		append using "Tables CR/cont_kappa_`k'_W-CR_w.dta"
	}

// Set baseline	
	// SET 0.00 WHEN THE FILE BECOMES AVAILABLE	
	replace cr = cr * 100
	replace cr = . if cr == 0 & id_eq == 0
	drop if cr != 0 & cr != . & id_eq == 0
	replace cr = cr / 100
	sort cr id_eq

// Mean Equilibrium Outcomes
	egen mean_dp = rowmean(dp_1 dp_2 dp_3 dp_4 dp_5)
	egen mean_ir_i = rowmean(ir_i_1 ir_i_2 ir_i_3 ir_i_4 ir_i_5)
	egen mean_ir_u = rowmean(ir_u_1 ir_u_2 ir_u_3 ir_u_4 ir_u_5)
	egen mean_ms_i = rowmean(ms_i_1 ms_i_2 ms_i_3 ms_i_4 ms_i_5)
	egen mean_ms_u = rowmean(ms_u_1 ms_u_2 ms_u_3 ms_u_4 ms_u_5)

// Welfare Measures
	foreach z in wc_tot aev fdic_pay bc_10 bc_20 cap_posted {
		gen d_`z' = `z' - `z'[_N]
	}
	
	drop w_00 w_10 w_20
	gen w_00 = d_wc_tot + d_aev - d_fdic_pay + d_cap_posted
	gen w_10 = d_wc_tot + d_aev - d_fdic_pay - d_bc_10 + d_cap_posted
	gen w_20 = d_wc_tot + d_aev - d_fdic_pay - d_bc_20 + d_cap_posted

	foreach z in d_wc_tot d_aev d_fdic_pay d_bc_10 d_bc_20 w_00 w_10 w_20 mean_dp mean_ir_i mean_ir_u mean_ms_i mean_ms_u ms_i_inside ms_u_inside {
		bysort cr: egen min_`z' = min(`z')
		bysort cr: egen max_`z' = max(`z')
	}

	gen n_eq = 1
	sort cr id_eq
	collapse (sum) n_eq (mean) min* max*, by(cr)

// Scale 
	gen kappa = cr / (1 - cr)
	order cr kappa 

// Optimal Kappa - CR
	foreach z in w_00 w_10 w_20 d_wc_tot d_aev  {
		egen max_min_`z' = max(min_`z') if kappa != . & kappa >= 0.0
		gen aux_`z' = 0
		replace aux_`z' = 1 if max_min_`z' == min_`z'
		gen max_min_kappa_`z'_aux = cr * aux_`z'
		egen max_min_kappa_`z' = max(max_min_kappa_`z'_aux)
		drop max_min_kappa_`z'_aux aux_`z' max_min_`z'
	}
	
	foreach z in d_fdic_pay d_bc_10 d_bc_20 {
		egen min_max_`z' = min(max_`z') if kappa != . & kappa >= 0.0
		gen aux_`z' = 0
		replace aux_`z' = 1 if min_max_`z' == max_`z'
		gen min_max_kappa_`z'_aux = cr * aux_`z'
		egen min_max_kappa_`z' = max(min_max_kappa_`z'_aux)
		drop min_max_kappa_`z'_aux aux_`z' min_max_`z'
	}
	
// Plots
// N
	twoway  (line n_eq cr if kappa != . & kappa >= 0.0, lwidth(0.5)    lpattern(solid) lcolor(gs0)), ///
				graphregion(color(white)) xlabel(0.0(0.1)0.5) ylabel(0.0(100)400) ///
				legend(lab(1 "Number of Equilibria")  ///
					   order(1) row(1)) ///
				 xline(0.08, lpattern(dash)) ///	   
				xtitle("Capital Requirement") ytitle("N") 
	graph export "Figures/n_eq_W-CR_w.png", replace width(1000)

// Equilibrium Outcomes
	twoway  (line max_mean_dp cr if kappa != . & kappa >= 0.0, lwidth(0.5)    lpattern(solid) lcolor(gs0)) ///
			(line min_mean_dp cr if kappa != . & kappa >= 0.0, lwidth(0.5)    lpattern(solid) lcolor(gs8)), ///
				graphregion(color(white)) xlabel(0.0(0.1)0.5) ylabel(0.0(0.2)1.0) ///
				legend(lab(1 "Worst Equilibrium") lab(2 "Best Equilibrium")  ///
					   order(1 2) row(1)) ///
				xline(0.08, lpattern(dash)) ///	   
				xtitle("Capital Requirement") ytitle("Mean Risk Neutral Default Pr.")
	graph export "Figures/dp_W-CR_w.png", replace width(1000)	

	twoway  (line min_mean_ir_i cr if kappa != . & kappa >= 0.0, lwidth(0.5)    lpattern(solid) lcolor(gs0)) ///
			(line max_mean_ir_i cr if kappa != . & kappa >= 0.0, lwidth(0.5)    lpattern(solid) lcolor(gs8)), ///
				graphregion(color(white)) xlabel(0.0(0.1)0.5) ylabel(-0.1(0.05)0.2) ///
				legend(lab(1 "Min(Mean i{superscript:I})") lab(2 "Max(Mean i{superscript:I})")  ///
					   order(1 2) row(1)) ///
				xtitle("Capital Requirement") ytitle("Mean i{superscript:I}") ///
				yline(0) xline(0.08, lpattern(dash)) 
	graph export "Figures/ir_i_W-CR_w.png", replace width(1000)	

	twoway  (line min_mean_ir_u cr if kappa != . & kappa >= 0.0, lwidth(0.5)    lpattern(solid) lcolor(gs0)) ///
			(line max_mean_ir_u cr if kappa != . & kappa >= 0.0, lwidth(0.5)    lpattern(solid) lcolor(gs8)), ///
				graphregion(color(white)) xlabel(0.0(0.1)0.5) ylabel(-0.1(0.05)0.2) ///
				legend(lab(1 "Min(Mean i{superscript:N})") lab(2 "Max(Mean i{superscript:N})")  ///
					   order(1 2) row(1)) ///
				xtitle("Capital Requirement") ytitle("Mean i{superscript:N}") ///
				yline(0) xline(0.08, lpattern(dash)) 
	graph export "Figures/ir_u_W-CR_w.png", replace width(1000)	

	twoway  (line min_ms_i_inside cr if kappa != . & kappa >= 0.0, lwidth(0.5)    lpattern(solid) lcolor(gs0)) ///
			(line max_ms_i_inside cr if kappa != . & kappa >= 0.0, lwidth(0.5)    lpattern(solid) lcolor(gs8)), ///
				graphregion(color(white)) xlabel(0.0(0.1)0.5) ylabel(0.0(0.2)1) ///
				legend(lab(1 "Min(Inside share)") lab(2 "Max(Inside share)")  ///
					   order(1 2) row(1)) ///
				xline(0.08, lpattern(dash)) ///	   
				xtitle("Capital Requirement") ytitle("Inside share (insured)")
	graph export "Figures/ms_i_inside_W-CR_w.png", replace width(1000)

	twoway  (line min_ms_u_inside cr if kappa != . & kappa >= 0.0, lwidth(0.5)    lpattern(solid) lcolor(gs0)) ///
			(line max_ms_u_inside cr if kappa != . & kappa >= 0.0, lwidth(0.5)    lpattern(solid) lcolor(gs8)), ///
				graphregion(color(white)) xlabel(0.0(0.1)0.5) ylabel(0.0(0.2)1) ///
				legend(lab(1 "Min(Inside share)") lab(2 "Max(Inside share)")  ///
					   order(1 2) row(1)) ///
				xline(0.08, lpattern(dash)) ///	   
				xtitle("Capital Requirement") ytitle("Inside share (insured)") 
	graph export "Figures/ms_u_inside_W-CR_w.png", replace width(1000)	

// W_00, W_10, W_20
	replace min_w_00 = min_w_00/1000
	replace max_w_00 = max_w_00/1000
	
	sum max_min_kappa_w_00, meanonly
	local max_min_kappa = r(mean)
	
	twoway  (line min_w_00 cr if kappa != . & kappa >= 0.0, lwidth(0.5)    lpattern(solid) lcolor(gs0)) ///
			(line max_w_00 cr if kappa != . & kappa >= 0.0, lwidth(0.5)    lpattern(solid) lcolor(gs8)), ///
				graphregion(color(white)) xlabel(0.0(0.1)0.5) ylabel(-3.5(.5).5) ylabel(, format(%9.1f)) ///
				legend(lab(1 "Worst  Equilibrium") lab(2 "Best Equilibrium")  ///
					   order(1 2) row(1)) ///
				xtitle("Capital Requirement") ytitle("Welfare (Trillions)") ///
				yline(0) xline(`max_min_kappa', lpattern(dash) lcolor(red)) 
	graph export "Figures/w_00_W-CR_w.png", replace width(1000)	

	sum max_min_kappa_w_10, meanonly
	local max_min_kappa = r(mean)

	twoway  (line min_w_10 cr if kappa != . & kappa >= 0.0, lwidth(0.5)    lpattern(solid) lcolor(gs0)) ///
			(line max_w_10 cr if kappa != . & kappa >= 0.0, lwidth(0.5)    lpattern(solid) lcolor(gs8)), ///
				graphregion(color(white)) xlabel(0.0(0.1)0.5) ylabel(-3500(500)500) ///
				legend(lab(1 "Worst  Equilibrium") lab(2 "Best Equilibrium")  ///
					   order(1 2) row(1)) ///
				xtitle("Capital Requirement") ytitle("Welfare (Billions, 10% BC)") ///
				yline(0) xline(`max_min_kappa', lpattern(dash) lcolor(red)) xline(0.08, lpattern(dash))
	graph export "Figures/w_10_W-CR_w.png", replace width(1000)	

	sum max_min_kappa_w_20, meanonly
	local max_min_kappa = r(mean)

	twoway  (line min_w_20 cr if kappa != . & kappa >= 0.0, lwidth(0.5)    lpattern(solid) lcolor(gs0)) ///
			(line max_w_20 cr if kappa != . & kappa >= 0.0, lwidth(0.5)    lpattern(solid) lcolor(gs8)), ///
				graphregion(color(white)) xlabel(0.0(0.1)0.5) ylabel(-3500(500)500) ///
				legend(lab(1 "Worst  Equilibrium") lab(2 "Best Equilibrium")  ///
					   order(1 2) row(1)) ///
				xtitle("Capital Requirement") ytitle("Welfare (Billions, 20% BC)") ///
				yline(0) xline(`max_min_kappa', lpattern(dash) lcolor(red)) xline(0.08, lpattern(dash))
	graph export "Figures/w_20_W-CR_w.png", replace width(1000)	

// WC
	sum max_min_kappa_d_wc_tot, meanonly
	local max_min_kappa = r(mean)

	twoway  (line min_d_wc_tot cr if kappa != . & kappa >= 0.0, lwidth(0.5)    lpattern(solid) lcolor(gs0)) ///
			(line max_d_wc_tot cr if kappa != . & kappa >= 0.0, lwidth(0.5)    lpattern(solid) lcolor(gs8)), ///
				graphregion(color(white)) xlabel(0.0(0.1)0.5) ylabel(-3000(500)1000) ///
				legend(lab(1 "Worst Equilibrium") lab(2 "Best Equilibrium")  ///
					   order(1 2) row(1)) ///
				xtitle("Capital Requirement") ytitle("Consumer Surplus (Billions)") ///
				yline(0) xline(`max_min_kappa', lpattern(dash) lcolor(red)) xline(0.08, lpattern(dash))
	graph export "Figures/wc_tot_W-CR_w.png", replace width(1000)

// AEV
	sum max_min_kappa_d_aev, meanonly
	local max_min_kappa = r(mean)

	twoway  (line min_d_aev cr if kappa != . & kappa >= 0.0, lwidth(0.5)    lpattern(solid) lcolor(gs0)) ///
			(line max_d_aev cr if kappa != . & kappa >= 0.0, lwidth(0.5)    lpattern(solid) lcolor(gs8)), ///
				graphregion(color(white)) xlabel(0.0(0.1)0.5) ylabel(-100(50)100) ///
				legend(lab(1 "Worst Equilibrium") lab(2 "Best Equilibrium")  ///
					   order(1 2) row(1)) ///
				xtitle("Capital Requirement") ytitle("Flow to Equity (Billions)") ///
				yline(0) xline(`max_min_kappa', lpattern(dash) lcolor(red)) xline(0.08, lpattern(dash))
	graph export "Figures/aev_W-CR_w.png", replace width(1000)

// FDIC Pay
	sum min_max_kappa_d_fdic_pay, meanonly
	local min_max_kappa = r(mean)

	twoway  (line max_d_fdic_pay cr if kappa != . & kappa >= 0.0, lwidth(0.5)    lpattern(solid) lcolor(gs0)) ///
			(line min_d_fdic_pay cr if kappa != . & kappa >= 0.0, lwidth(0.5)    lpattern(solid) lcolor(gs8)), ///
				graphregion(color(white)) xlabel(0.0(0.1)0.5) ylabel(0.0(500)2000) ///
				legend(lab(1 "Worst Equilibrium") lab(2 "Best Equilibrium")  ///
				order(1 2) row(1)) ///
				xtitle("Capital Requirement") ytitle("Expected FDIC Losses (Billions)") ///
				yline(0) xline(`min_max_kappa', lpattern(dash) lcolor(red)) xline(0.08, lpattern(dash))
	graph export "Figures/fdic_pay_W-CR_w.png", replace width(1000)

// BC_10, BC_20
	sum min_max_kappa_d_bc_10, meanonly
	local min_max_kappa = r(mean)

	twoway  (line max_d_bc_10 cr if kappa != . & kappa >= 0.0, lwidth(0.5)    lpattern(solid) lcolor(gs0)) ///
			(line min_d_bc_10 cr if kappa != . & kappa >= 0.0, lwidth(0.5)    lpattern(solid) lcolor(gs8)), ///
				graphregion(color(white)) xlabel(0.0(0.1)0.5) ylabel(0.0(250)750) ///
				legend(lab(1 "Worst Equilibrium") lab(2 "Best Equilibrium")  ///
				order(1 2) row(1)) ///
				xtitle("Capital Requirement") ytitle("Expected Bankruptcy Cost (Billions, 10%)") ///
				yline(0) xline(`min_max_kappa', lpattern(dash) lcolor(red)) xline(0.08, lpattern(dash))
	graph export "Figures/bc_10_W-CR_w.png", replace width(1000)

	sum min_max_kappa_d_bc_20, meanonly
	local min_max_kappa = r(mean)

	twoway  (line max_d_bc_20 cr if kappa != . & kappa >= 0.0, lwidth(0.5)    lpattern(solid) lcolor(gs0)) ///
			(line min_d_bc_20 cr if kappa != . & kappa >= 0.0, lwidth(0.5)    lpattern(solid) lcolor(gs8)), ///
				graphregion(color(white)) xlabel(0.0(0.1)0.5) ylabel(0.0(250)750) ///
				legend(lab(1 "Worst Equilibrium") lab(2 "Best Equilibrium")  ///
				order(1 2) row(1)) ///
				xtitle("Capital Requirement") ytitle("Expected Bankruptcy Cost (Billions, 20%)") ///
				yline(0) xline(`min_max_kappa', lpattern(dash) lcolor(red)) xline(0.08, lpattern(dash))
	graph export "Figures/bc_20_W-CR_w.png", replace width(1000)

sum max_min_kappa_w_00
*Save Data
order kappa cr n_eq min_mean_dp max_mean_dp min_mean_ir_i max_mean_ir_i min_mean_ir_u max_mean_ir_u min_mean_ms_i max_mean_ms_i min_mean_ms_u max_mean_ms_u min_ms_i_inside max_ms_i_inside min_ms_u_inside max_ms_u_inside  min_w_00 max_w_00 min_w_10 max_w_10 min_w_20 max_w_20 min_d_wc_tot max_d_wc_tot min_d_aev max_d_aev min_d_fdic_pay max_d_fdic_pay min_d_bc_10 max_d_bc_10 min_d_bc_20 max_d_bc_20
keep kappa cr n_eq min_mean_dp max_mean_dp min_mean_ir_i max_mean_ir_i min_mean_ir_u max_mean_ir_u min_mean_ms_i max_mean_ms_i min_mean_ms_u max_mean_ms_u min_ms_i_inside max_ms_i_inside min_ms_u_inside max_ms_u_inside  min_w_00 max_w_00 min_w_10 max_w_10 min_w_20 max_w_20 min_d_wc_tot max_d_wc_tot min_d_aev max_d_aev min_d_fdic_pay max_d_fdic_pay min_d_bc_10 max_d_bc_10 min_d_bc_20 max_d_bc_20
save "Tables CR/results_W-CR_w.dta", replace
export excel using "Tables CR/results_W-CR_w.xlsx", firstrow(variables) replace
