cd "H:\My Documents\Research\Deposit Competition\R - Files\AER Version\Baseline - Safe Assets"
use "Tables CR/results_W-CR_w.dta", clear
keep min_w_00 max_w_00 cr kappa
rename min_w_00 min_safe_asset
rename max_w_00 max_safe_asset
cd "H:\My Documents\Research\Deposit Competition\R - Files\AER Version\Baseline"
merge 1:1 cr using "Tables CR/results_W-CR_w.dta", keepusing(min_w_00 max_w_00)
cd "H:\My Documents\Research\Deposit Competition\R - Files\AER Version\Baseline - Safe Assets"
//replace min_w_00 = min_w_00/1000
//replace max_w_00 = max_w_00/1000
//replace min_safe_asset = min_safe_asset/1000
//replace max_safe_asset = max_safe_asset/1000


twoway  (line min_w_00 cr if kappa != . & kappa >= 0.0, lwidth(0.5)    lpattern(solid) lcolor(gs0)) ///
		(line max_w_00 cr if kappa != . & kappa >= 0.0, lwidth(0.5)    lpattern(solid) lcolor(gs8)) ///
		(line min_safe_asset cr if kappa != . & kappa >= 0.0, lwidth(0.5)    lpattern(dash) lcolor(gs0)) ///
		(line max_safe_asset cr if kappa != . & kappa >= 0.0, lwidth(0.5)    lpattern(dash) lcolor(gs8)), ///
		graphregion(color(white)) xlabel(0.0(0.1)0.5) ylabel(-3.5(.5).5) ylabel(, format(%9.1f)) ///
		legend(lab(1 "Worst  Eq") lab(2 "Best Eq") lab(3 "Worst  Eq: Safe Asset") lab(4 "Best  Eq: Safe Asset")  ///
		order(1 2 3 4) row(2)) ///
		xtitle("Capital Requirement") ytitle("Welfare (Trillions)") ///
		yline(0) 
graph export "Figures/welfare_combined.png", replace width(1000)	
