##############################################################################
##############################################################################
######                                                                  ######
######            Deposit Compeition and Financial Fragility            ###### 
######                  Optimal Capital Req: Equity Adj. Costs          ######
######                          06/20/2016                              ######
######           By Mark Egan, Ali Hortacsu and Gregor Matvos           ######
######                                                                  ######
##############################################################################
##############################################################################

### Contents ###
# 1. Load files and data 
# 2. Calibrate the model
# 3. Create functions for searching for equilibria
# 4. Search for multiple equilibria 
# 5. Search for multiple equilibria with interest rate caps
# 6. Optimal Capital Req.

##############################################################################1

######################################
####    1. Load Files and Data    ####
######################################

#######################
### 1(a) Load Files ###
#######################

.libPaths( c( .libPaths(), "H:/Rpackages") )
library(doSNOW)
library(foreach)
library(nleqslv)
rm(list = ls())
setwd("H:/My Documents/Research/Deposit Competition/R - Files/AER Version/Issuance Costs")
date<- "31mar2008"
df.full<- read.csv("H:/My Documents/Research/Deposit Competition/R - Files/calibration params final.csv")
#df.full$cap.i<- df.full$cmt1y+.05
df.full$cap.i<- 100
df.full$cap.u<- 100
df<-df.full[df.full$date==date& (!is.na(df.full$b)),]

######################
### 1(b) Prep Data ###
######################
df<-df[df$unins_share>0.03,]
t_d <-0.00
t_r<- 0.05
df$kappa<- df$eq_ratio*0 
df$o_unins_share<- 1-sum(df$unins_share)
df$o_ins_share<- 1-sum(df$ins_share)
p.i<- df$ins_rate
p.u<- df$unins_rate
gamma<- df$gamma
delta.u<-df$delta_u
delta.i<-df$delta_i
alpha.u<-df$alpha_unins
alpha.i<-df$alpha_ins
hazard<-df$hazard
#This calculates the unobserved error term from the demand regression that gives us the observed market share
error.u<- log(df$unins_share)-log(df$o_unins_share[1])-(alpha.u*p.u+delta.u+hazard*gamma)
error.i<- log(df$ins_share)-log(df$o_ins_share[1])-(alpha.i*p.i+delta.i)
outside.u<- (1/df$o_unins_share[1]-sum(exp(alpha.u*p.u+delta.u+hazard*gamma+error.u)))
outside.i<- (1/df$o_ins_share[1]-sum(exp(alpha.i*p.i+delta.i+error.i)))
r<-df$int_rate
r.eq<-r
kappa<-df$kappa
M.u<- df$M_u
M.i<- df$M_i
b<-df$b
cap.i<- df$cap.i[1]
cap.u<- df$cap.u[1]

##############################################################################1

######################################
####    2. Calibrate the Model    ####
######################################

############################################
### 2(a) Function to Calibrate the Model ###
############################################
fn.calib <-function(params,p.u,p.i,hazard,gamma,delta.u,delta.i,alpha.u,alpha.i,b,M.u,M.i,error.i,error.u,outside.u, outside.i,r,cap.i,cap.u,k,r.eq,t_d,t_r){
  mu <- params[1:5]
  sd <- params[6:10]
  c<-params[11:15]
  numer.u<-exp(alpha.u*p.u+delta.u+hazard*gamma+error.u)
  denom.u<- sum(numer.u)+outside.u
  s.u<- numer.u/denom.u
  numer.i<-exp(alpha.i*p.i+delta.i +error.i)
  denom.i<- sum(numer.i)+outside.i
  s.i<- numer.i/denom.i
  r.bar<- qnorm(hazard)*sd+mu
  r.bar.n<- qnorm(hazard)
  r.star.n<- ((b+s.u*M.u*p.u+s.i*M.i*(p.i+c)+r.eq*k*(s.u*M.u+s.i*M.i+b))/((s.u*M.u+s.i*M.i)*(1+k)+b*k)-mu)/sd
  eq.u<- (1+t_r)*alpha.u*(1-s.u)*(mu*(1+k)-p.u-r.eq*k+(1+k)*sd*dnorm(r.bar.n)/(1-pnorm(r.bar.n)))*(1-pnorm(r.bar.n))-(1+t_r)*(1-pnorm(r.bar.n))+(1-t_d)*alpha.u*(1-s.u)*((1+k)*mu-p.u-r.eq*k+(1+k)*sd*dnorm(r.star.n)/(1-pnorm(r.star.n)))*(1-pnorm(r.star.n))-(1-t_d)*(1-pnorm(r.star.n))-(1+t_r)*alpha.u*(1-s.u)*((1+k)*mu-p.u-r.eq*k+(1+k)*sd*dnorm(r.star.n)/(1-pnorm(r.star.n)))*(1-pnorm(r.star.n))+(1+t_r)*(1-pnorm(r.star.n))-k*alpha.u*(1-s.u)*pnorm(r.bar.n)
  eq.i<- (1+t_r)*alpha.i*(1-s.i)*(mu*(1+k)-p.i-c-r.eq*k+(1+k)*sd*dnorm(r.bar.n)/(1-pnorm(r.bar.n)))*(1-pnorm(r.bar.n))-(1+t_r)*(1-pnorm(r.bar.n))+(1-t_d)*alpha.i*(1-s.i)*((1+k)*mu-p.i-c-r.eq*k+(1+k)*sd*dnorm(r.star.n)/(1-pnorm(r.star.n)))*(1-pnorm(r.star.n))-(1-t_d)*(1-pnorm(r.star.n))-(1+t_r)*alpha.i*(1-s.i)*((1+k)*mu-p.i-c-r.eq*k+(1+k)*sd*dnorm(r.star.n)/(1-pnorm(r.star.n)))*(1-pnorm(r.star.n))+(1+t_r)*(1-pnorm(r.star.n))-k*alpha.i*(1-s.i)*pnorm(r.bar.n)
  lhs<-((1+t_r)*(1+r)/(s.u*M.u+M.i*s.i+b))*(b*(1-k/(1+t_r))-s.u*M.u*(r.bar-p.u+k/(1+t_r))-s.i*M.i*(r.bar-c-p.i+k/(1+t_r))-k*(s.u*M.u+s.i*M.i+b)*(r.bar-r.eq)) 
  rhs<- -k +(k+(s.u*M.u+M.i*s.i)/(s.u*M.u+M.i*s.i+b))*(1+t_r)*((mu-r.bar)*(pnorm(r.star.n)-pnorm(r.bar.n))+sd*dnorm(r.bar.n)-sd*dnorm(r.star.n))+(k+(s.u*M.u+M.i*s.i)/(s.u*M.u+M.i*s.i+b))*(1-t_d)*((mu-r.bar)*(1-pnorm(r.star.n))+sd*dnorm(r.star.n))
  eq.haz<- lhs-rhs 
  res<- cbind(t(eq.u),t(eq.i),matrix(eq.haz,ncol=5,nrow=1))
  return(res)
}
########################
### 2(b) Calibration ###
########################
params<-c(df$mu,df$sd,df$c)
fn.calib(params,p.u,p.i,hazard,gamma,delta.u,delta.i,alpha.u,alpha.i,b,M.u,M.i,error.i,error.u,outside.u, outside.i,r,cap.i,cap.u,kappa,r.eq,t_d,t_r)
find.eq<- nleqslv(params,fn.calib,control=list(maxit=5000,ftol=1e-12, xtol=1e-12),p.u=p.u,p.i=p.i,hazard=hazard,gamma=gamma,delta.u=delta.u,delta.i=delta.i,alpha.u=alpha.u,alpha.i=alpha.i,b=b,M.u=M.u,M.i=M.i,error.i=error.i,error.u=error.u,outside.u=outside.u,outside.i=outside.i,r=r,cap.i=cap.i,cap.u=cap.u,k=kappa,r.eq=r.eq,t_d=t_d,t_r=t_r)    
params<-find.eq$x
find.eq<- nleqslv(params,fn.calib,control=list(maxit=5000,ftol=1e-12, xtol=1e-12),p.u=p.u,p.i=p.i,hazard=hazard,gamma=gamma,delta.u=delta.u,delta.i=delta.i,alpha.u=alpha.u,alpha.i=alpha.i,b=b,M.u=M.u,M.i=M.i,error.i=error.i,error.u=error.u,outside.u=outside.u,outside.i=outside.i,r=r,cap.i=cap.i,cap.u=cap.u,k=kappa,r.eq=r.eq,t_d=t_d,t_r=t_r)    

mu<- find.eq$x[1:5]
sd<- find.eq$x[6:10]
c<- find.eq$x[11:15]
df$mu<-mu
df$sd<-sd
df$c<-c 


##############################################################################

###########################################################
####    3. Create Functions for Finding Equilibrium    ####
###########################################################

##########################################################
### 3(a) Caluclate Equilibrium  First Order Conditions ###
##########################################################
# This function checks and reports the 15 first order conditions for the banks
fn.eqFOC <-function(params,mu,sd,gamma,delta.u,delta.i,alpha.u,alpha.i,b,M.u,M.i,error.i,error.u,c,outside.u, outside.i,r,cap.i,cap.u,k,r.eq,t_d,t_r){
  p.u <- params[1:5]
  p.i <- params[6:10]
  p.i[p.i>cap.i]<-cap.i
  p.u[p.u>cap.u]<-cap.u
  e.hazard<-params[11:15]
  numer.u<-exp(alpha.u*p.u+delta.u+e.hazard*gamma+error.u)
  denom.u<- sum(numer.u)+outside.u
  s.u<- numer.u/denom.u
  numer.i<-exp(alpha.i*p.i+delta.i +error.i)
  denom.i<- sum(numer.i)+outside.i
  s.i<- numer.i/denom.i
  r.bar<- qnorm(e.hazard)*sd+mu
  r.bar.n<- qnorm(e.hazard)
  r.star.n<- ((b+s.u*M.u*p.u+s.i*M.i*(p.i+c)+r.eq*k*(s.u*M.u+s.i*M.i+b))/((s.u*M.u+s.i*M.i)*(1+k)+b*k)-mu)/sd
  eq.u<- (1+t_r)*alpha.u*(1-s.u)*(mu*(1+k)-p.u-r.eq*k+(1+k)*sd*dnorm(r.bar.n)/(1-pnorm(r.bar.n)))*(1-pnorm(r.bar.n))-(1+t_r)*(1-pnorm(r.bar.n))+(1-t_d)*alpha.u*(1-s.u)*((1+k)*mu-p.u-r.eq*k+(1+k)*sd*dnorm(r.star.n)/(1-pnorm(r.star.n)))*(1-pnorm(r.star.n))-(1-t_d)*(1-pnorm(r.star.n))-(1+t_r)*alpha.u*(1-s.u)*((1+k)*mu-p.u-r.eq*k+(1+k)*sd*dnorm(r.star.n)/(1-pnorm(r.star.n)))*(1-pnorm(r.star.n))+(1+t_r)*(1-pnorm(r.star.n))-k*alpha.u*(1-s.u)*pnorm(r.bar.n)
  eq.i<- (1+t_r)*alpha.i*(1-s.i)*(mu*(1+k)-p.i-c-r.eq*k+(1+k)*sd*dnorm(r.bar.n)/(1-pnorm(r.bar.n)))*(1-pnorm(r.bar.n))-(1+t_r)*(1-pnorm(r.bar.n))+(1-t_d)*alpha.i*(1-s.i)*((1+k)*mu-p.i-c-r.eq*k+(1+k)*sd*dnorm(r.star.n)/(1-pnorm(r.star.n)))*(1-pnorm(r.star.n))-(1-t_d)*(1-pnorm(r.star.n))-(1+t_r)*alpha.i*(1-s.i)*((1+k)*mu-p.i-c-r.eq*k+(1+k)*sd*dnorm(r.star.n)/(1-pnorm(r.star.n)))*(1-pnorm(r.star.n))+(1+t_r)*(1-pnorm(r.star.n))-k*alpha.i*(1-s.i)*pnorm(r.bar.n)
  #Check for corner solutions
  eq.i[p.i==cap.i]<- eq.i[p.i==cap.i]*(eq.i[p.i==cap.i]>0)
  eq.u[p.u==cap.u]<- eq.u[p.u==cap.u]*(eq.u[p.u==cap.u]>0)
  lhs<-((1+t_r)*(1+r)/(s.u*M.u+M.i*s.i+b))*(b*(1-k/(1+t_r))-s.u*M.u*(r.bar-p.u+k/(1+t_r))-s.i*M.i*(r.bar-c-p.i+k/(1+t_r))-k*(s.u*M.u+s.i*M.i+b)*(r.bar-r.eq)) 
  rhs<- -k +(k+(s.u*M.u+M.i*s.i)/(s.u*M.u+M.i*s.i+b))*(1+t_r)*((mu-r.bar)*(pnorm(r.star.n)-pnorm(r.bar.n))+sd*dnorm(r.bar.n)-sd*dnorm(r.star.n))+(k+(s.u*M.u+M.i*s.i)/(s.u*M.u+M.i*s.i+b))*(1-t_d)*((mu-r.bar)*(1-pnorm(r.star.n))+sd*dnorm(r.star.n))
  eq.haz<- lhs-rhs 
  res<- cbind(t(eq.u),t(eq.i),matrix(eq.haz,ncol=5,nrow=1))
  return(res)
}

#############################
### 3(b) Find Equilibrium ###
#############################
# This uses the function nleqslv to find equilibria
fn.findEq<- function(params,mu,sd,gamma,delta.u,delta.i,alpha.u,alpha.i,b,M.u,M.i,error.i,error.u,c,outside.u,outside.i,r,cap.i,cap.u,k,r.eq,t_d,t_r){
  find.eq<- nleqslv(params,fn.eqFOC,control=list(maxit=5000,xtol=1e-10,ftol=1e-10),mu=mu,sd=sd,gamma=gamma,delta.u=delta.u,delta.i=delta.i,alpha.u=alpha.u,alpha.i=alpha.i,b=b,M.u=M.u,M.i=M.i,error.i=error.i,error.u=error.u,c=c,outside.u=outside.u,outside.i=outside.i,r=r,cap.i=cap.i,cap.u=cap.u,k=k,r.eq=r.eq,t_d=t_d,t_r=t_r)    
  res<- find.eq$x
  r1<- res[1:5]
  r2<- res[6:10]
  r1[r1>cap.u]<-cap.u
  r2[r2>cap.i]<-cap.i
  res[1:5]<-r1
  res[6:10]<-r2
  if(find.eq$termcd!=1){
    res<- res*0
  }
  return(t(cbind(t(res),t(find.eq$f))))
}


##############################################################################1

##########################################
####    4. Search for Mutliple Eq.    ####
##########################################

##################################
### 4(a) Create Grid to Search ###
##################################

# Construct grid of starting points for default probabilities
n <- 5
hazard.grid <- matrix(0.01,5,n^5)
results <- matrix(0,1,n^5)
if (n==9){
  for (i in 1:5){
    hazard.grid[i,] <- rep(c(rep(0.00001,n^5/(9^i)),rep(0.01,n^5/(9^i)),rep(0.05,n^5/(9^i)),rep(0.1,n^5/(9^i)),rep(0.2,n^5/(9^i)),rep(0.3,n^5/(9^i)),rep(0.5,n^5/(9^i)),rep(0.65,n^5/(9^i)),rep(0.9,n^5/(9^i))),9^(i-1))
  }  
}else if (n==8){
  for (i in 1:5){
    hazard.grid[i,] <- rep(c(rep(0.00001,n^5/(8^i)),rep(0.025,n^5/(8^i)),rep(0.05,n^5/(8^i)),rep(0.1,n^5/(8^i)),rep(0.2,n^5/(8^i)),rep(0.4,n^5/(8^i)),rep(0.65,n^5/(8^i)),rep(0.9,n^5/(8^i))),8^(i-1))
  }  
}else if (n==7){
  for (i in 1:5){
    hazard.grid[i,] <- rep(c(rep(0.00001,n^5/(7^i)),rep(0.05,n^5/(7^i)),rep(0.1,n^5/(7^i)),rep(0.2,n^5/(7^i)),rep(0.4,n^5/(7^i)),rep(0.65,n^5/(7^i)),rep(0.9,n^5/(7^i))),7^(i-1))
  }
}else if (n==6){
  for (i in 1:5){
    hazard.grid[i,] <- rep(c(rep(0.00001,n^5/(6^i)),rep(0.05,n^5/(6^i)),rep(0.1,n^5/(6^i)),rep(0.4,n^5/(6^i)),rep(0.65,n^5/(6^i)),rep(0.9,n^5/(6^i))),6^(i-1))
  }
}else if (n==5){
  for (i in 1:5){
    hazard.grid[i,] <- rep(c(rep(0.00001,n^5/(5^i)),rep(0.05,n^5/(5^i)),rep(0.2,n^5/(5^i)),rep(0.7,n^5/(5^i)),rep(0.9,n^5/(5^i))),5^(i-1))
  }
}else if (n==4){
  for (i in 1:5){
    hazard.grid[i,] <- rep(c(rep(0.00001,n^5/(4^i)),rep(0.05,n^5/(4^i)),rep(0.2,n^5/(4^i)),rep(0.9,n^5/(4^i))),4^(i-1))
  }  
}else if (n==3){
  for (i in 1:5){
    hazard.grid[i,] <- rep(c(rep(0.05,n^5/(3^i)),rep(0.5,n^5/(3^i)),rep(0.85,n^5/(3^i))),3^(i-1))
  }
}else{
  for (i in 1:5){
    hazard.grid[i,] <- rep(c(rep(0.05,n^5/(2^i)),rep(0.6,n^5/(2^i))),2^(i-1))
  }
}

z.grid <- c(rep(0,15))
i.grid <- matrix(0.01,length(hazard.grid)/5,nrow=5)
#params <- t(cbind(t(p.u),t(p.i),t(df$hazard)))
hazard.grid.m <- cbind(z.grid,rbind(i.grid,i.grid,hazard.grid))

##########################################
### 4(b) Check for Multiple Equilibria ###
##########################################

# We set interest rates to 1% for each bank in each iteration
kappa<- 0
cl <- makeCluster(24)
registerDoSNOW(cl)
writeLines(c(""), "log.txt")
sink("log.txt", append=TRUE)
eq <- foreach (i = 1:(n^5)+1,.combine='cbind',.packages=c("nleqslv"),.errorhandling=c('remove'))  %dopar% {
  cat(paste("Starting iteration",i,"\n"),file="log.txt", append=TRUE)
  fn.findEq((hazard.grid.m[,i]),mu,sd,gamma,delta.u,delta.i,alpha.u,alpha.i,b,M.u,M.i,error.i,error.u,c,outside.u, outside.i,r,cap.i,cap.u,kappa,r,t_d,t_r)
}
sink()
stopCluster(cl)
colnames(eq) <- colnames(eq, do.NULL = FALSE, prefix = "result.")
eq.r <- round(eq,1)
eq.unique.temp <- unique(eq.r[11:15,],MARGIN=2)
eq.unique <- eq[,c( colnames(eq.unique.temp))]
zeros <- rep(0,15)
results <- cbind(t(cbind(t(p.u),t(p.i),t(hazard),t(zeros))),eq.unique)

#Compute Shares
numer.i.s <- matrix(exp(alpha.i*results[6:10,]+delta.i +error.i),nrow=5)
denom.i.s <- colSums(numer.i.s)+outside.i
share.i.s <- t(t(numer.i.s)/denom.i.s)
tot.share.i.s <- colSums(share.i.s)
numer.u.s <- matrix(exp(alpha.u*results[1:5,] + results[11:15,]*gamma + delta.u + error.u),nrow=5)
denom.u.s <- colSums(numer.u.s)+outside.u
share.u.s <- t(t(numer.u.s)/denom.u.s)
tot.share.u.s <- colSums(share.u.s)

#Welfare  
#CS
wc.i <- matrix((1/alpha.i[1]) * log(colSums(numer.i.s)),nrow = 1)
wc.u <- matrix((1/alpha.u[1]) * log(colSums(numer.u.s)),nrow = 1)
wc.tot <- (M.i[1] * wc.i + M.u[1] * wc.u)/1000000

#AEV
r.bar <- mu + sd * qnorm(results[11:15,])
aev.ind <- r[1] * (1+t_r) * (1+r[1]) * (b * (1 - kappa/(1+t_r)) - share.u.s * M.u * (r.bar - results[1:5,] + kappa/(1+t_r)) - share.i.s * M.i * (r.bar - c - results[6:10,] + kappa/(1+t_r)) - kappa * (b + share.u.s * M.u + share.i.s * M.i) * (r.bar - r[1]))
aev <- matrix(colSums(aev.ind)/1000000,nrow = 1)  

#FDIC cost
fdic.cost <- matrix(colSums(M.i*share.i.s[1:5,]*results[11:15,]*(1-0.4))/1000000,nrow = 1)

#Bankruptcy costs
bc.cost.10 <- 0.1 * matrix(colSums(results[11:15,] * (M.i[1] * share.i.s[1:5,] + M.u[1] * share.u.s[1:5,]))/1000000,nrow = 1)
bc.cost.20 <- 0.2 * matrix(colSums(results[11:15,] * (M.i[1] * share.i.s[1:5,] + M.u[1] * share.u.s[1:5,]))/1000000,nrow = 1)

#Totals
w.00 <- wc.tot + aev - fdic.cost - (wc.tot[1,1] + aev[1,1] - fdic.cost[1,1])
w.10 <- wc.tot + aev - fdic.cost - bc.cost.10 - (wc.tot[1,1] + aev[1,1] - fdic.cost[1,1] - bc.cost.10[1,1])
w.20 <- wc.tot + aev - fdic.cost - bc.cost.20 - (wc.tot[1,1] + aev[1,1] - fdic.cost[1,1] - bc.cost.20[1,1])

#Prepare output
results.s <- rbind(results[6:10,],results[1:5,],results[11:15,],share.i.s,tot.share.i.s,share.u.s,tot.share.u.s,wc.tot,aev,fdic.cost,bc.cost.10,bc.cost.20,w.00,w.10,w.20)
rownames(results.s) <- c("ins_rate_JPM",  "ins_rate_BOA",  "ins_rate_Wells",  "ins_rate_Citi",  "ins_rate_Wach",	"unins_rate_JPM",	"unins_rate_BOA",	"unins_rate_Wells",	"unins_rate_Citi",	"unins_rate_Wach",	"default_prob_JPM",	"default_prob_BOA",	"default_prob_Wells",	"default_prob_Citi",	"default_prob_Wach",	"ins_share_JPM",	"ins_share_BOA",	"ins_share_Wells",	"ins_share_Citi",	"ins_share_Wach",	"ins_share_Cumulative",	"unins_share_JPM",	"unins_share_BOA",	"unins_share_Wells",	"unins_share_Citi",	"unins_share_Wach",	"unins_share_Cumulative","wc_tot","aev","fdic_ins_cost","bc_cost_10","bc_cost_20","w_00","w_10","w_20")
results.s.t <- t(results.s)
t <- data.frame(results.s.t)
t1 <- t[1,]
t2 <- t[-1,]
t2 <- t2[ order(-t2$w_00), ]
t3 <- rbind(t1,t2)
results.table <- t(t3)

#Output file
filename <- paste("Tables/5 bank eqm W-CR WO-CAP for ",date,".csv", sep="")
write.csv(results.table, file=filename)

##############################################################################

##################################################################
####    5. Search for Mutliple Eq. with Interest Rate Caps    ####
##################################################################

##########################################
### 5(a) Check for Multiple Equilibria ###
##########################################

# We set interest rates to 1% for each bank in each iteration
cap.i<- df$cmt1y+.05
cl <- makeCluster(24)
registerDoSNOW(cl)
writeLines(c(""), "log.txt")
sink("log.txt", append=TRUE)
eq <- foreach (i = 1:(n^5)+1,.combine='cbind',.packages=c("nleqslv"),.errorhandling=c('remove'))  %dopar% {
  cat(paste("Starting iteration",i,"\n"),file="log.txt", append=TRUE)
  fn.findEq((hazard.grid.m[,i]),mu,sd,gamma,delta.u,delta.i,alpha.u,alpha.i,b,M.u,M.i,error.i,error.u,c,outside.u, outside.i,r,cap.i,cap.u,kappa,r,t_d,t_r)
}
sink()
stopCluster(cl)
colnames(eq) <- colnames(eq, do.NULL = FALSE, prefix = "result.")
eq.r <- round(eq,1)
eq.unique.temp <- unique(eq.r[11:15,],MARGIN=2)
eq.unique <- eq[,c( colnames(eq.unique.temp))]
zeros <- rep(0,15)
results.c <- cbind(t(cbind(t(p.u),t(p.i),t(hazard),t(zeros))),eq.unique)

# Compute Shares
numer.i.s.c <- matrix(exp(alpha.i*results.c[6:10,]+delta.i +error.i),nrow=5)
denom.i.s.c <- colSums(numer.i.s.c)+outside.i
share.i.s.c <- t(t(numer.i.s.c)/denom.i.s.c)
tot.share.i.s.c <- colSums(share.i.s.c)
numer.u.s.c <- matrix(exp(alpha.u*results.c[1:5,] + results.c[11:15,]*gamma + delta.u + error.u),nrow=5)
denom.u.s.c <- colSums(numer.u.s.c)+outside.u
share.u.s.c <- t(t(numer.u.s.c)/denom.u.s.c)
tot.share.u.s.c <- colSums(share.u.s.c)

#Welfare  
#CS
wc.i.c <- matrix((1/alpha.i[1]) * log(colSums(numer.i.s.c)),nrow = 1)
wc.u.c <- matrix((1/alpha.u[1]) * log(colSums(numer.u.s.c)),nrow = 1)
wc.tot.c <- (M.i[1] * wc.i.c + M.u[1] * wc.u.c)/1000000

#AEV
r.bar.c <- mu + sd * qnorm(results.c[11:15,])
aev.ind.c <- r[1] * (1+r[1]) * (1+t_r) * (b * (1 - kappa/(1+t_r)) - share.u.s.c * M.u * (r.bar.c - results.c[1:5,] + kappa/(1+t_r)) - share.i.s.c * M.i * (r.bar.c - c - results.c[6:10,] + kappa/(1+t_r)) - kappa * (b + share.u.s.c * M.u + share.i.s.c * M.i) * (r.bar.c - r[1]))
aev.c <- matrix(colSums(aev.ind.c)/1000000,nrow = 1)  

#FDIC cost
fdic.cost.c <- matrix(colSums(M.i*share.i.s.c[1:5,]*results.c[11:15,]*(1-0.4))/1000000,nrow = 1)

#Bankruptcy costs
bc.cost.10.c <- 0.1 * matrix(colSums(results.c[11:15,] * (M.i[1] * share.i.s.c[1:5,] + M.u[1] * share.u.s.c[1:5,]))/1000000,nrow = 1)
bc.cost.20.c <- 0.2 * matrix(colSums(results.c[11:15,] * (M.i[1] * share.i.s.c[1:5,] + M.u[1] * share.u.s.c[1:5,]))/1000000,nrow = 1)

#Totals
w.00.c <- wc.tot.c + aev.c - fdic.cost.c                - (wc.tot.c[1,1] + aev.c[1,1] - fdic.cost.c[1,1])
w.10.c <- wc.tot.c + aev.c - fdic.cost.c - bc.cost.10.c - (wc.tot.c[1,1] + aev.c[1,1] - fdic.cost.c[1,1] - bc.cost.10.c[1,1])
w.20.c <- wc.tot.c + aev.c - fdic.cost.c - bc.cost.20.c - (wc.tot.c[1,1] + aev.c[1,1] - fdic.cost.c[1,1] - bc.cost.20.c[1,1])

#Prepare output
results.s.c <- rbind(results.c[6:10,],results.c[1:5,],results.c[11:15,],share.i.s.c,tot.share.i.s.c,share.u.s.c,tot.share.u.s.c,wc.tot.c,aev.c,fdic.cost.c,bc.cost.10.c,bc.cost.20.c,w.00.c,w.10.c,w.20.c)
rownames(results.s.c) <- c("ins_rate_JPM",  "ins_rate_BOA",  "ins_rate_Wells",  "ins_rate_Citi",  "ins_rate_Wach",  "unins_rate_JPM",	"unins_rate_BOA",	"unins_rate_Wells",	"unins_rate_Citi",	"unins_rate_Wach",	"default_prob_JPM",	"default_prob_BOA",	"default_prob_Wells",	"default_prob_Citi",	"default_prob_Wach",	"ins_share_JPM",	"ins_share_BOA",	"ins_share_Wells",	"ins_share_Citi",	"ins_share_Wach",	"ins_share_Cumulative",	"unins_share_JPM",	"unins_share_BOA",	"unins_share_Wells",	"unins_share_Citi",	"unins_share_Wach",	"unins_share_Cumulative","wc_tot","aev","fdic_ins_cost","bc_cost_10","bc_cost_20","w_00","w_10","w_20")
results.s.t.c <- t(results.s.c)
t.c <- data.frame(results.s.t.c)
t1.c <- t.c[1,]
t2.c <- t.c[-1,]
t2.c <- t2.c[ order(-t2.c$w_00), ]
t3.c <- rbind(t1.c,t2.c)
results.table.c <- t(t3.c)

#Output file
filename.c <- paste("Tables/5 bank eqm W-CR W-CAP for ",date,".csv", sep="")
write.csv(results.table.c, file=filename.c)

##############################################################################

#######################################
####    6. Optimal Capital Req.    ####
#######################################
#Set grid for CR values
omega.cr <- seq(0,0.5,length=51)
kappa.cr <- omega.cr / (1 - omega.cr)
cap.i<- 100
########################################################
### 6.a Check for Multiple Equilibria -- First round ###
########################################################

cl <- makeCluster(24)
registerDoSNOW(cl)
foreach (i=1:length(kappa.cr)) %do% {  
  kappa.cr.aux <- kappa.cr[i]
  omega.cr.aux <- omega.cr[i] 
  writeLines(c(""), "log.txt")
  sink("log.txt", append=TRUE)
  eq <- foreach (i = 1:(n^5),.combine='cbind',.packages=c("nleqslv"),.errorhandling=c('remove'))  %dopar% {
    cat(paste("Starting iteration",i,"\n"),file="log.txt", append=TRUE)
    fn.findEq((hazard.grid.m[,i]),mu,sd,gamma,delta.u,delta.i,alpha.u,alpha.i,b,M.u,M.i,error.i,error.u,c,outside.u, outside.i,r,cap.i,cap.u,kappa.cr.aux,r,t_d,t_r)
  }
  sink()
  colnames(eq) <- colnames(eq, do.NULL = FALSE, prefix = "result.")
  eq.r <- round(eq,2)
  eq.unique.temp<-unique(eq.r[11:15,],MARGIN=2)
  eq.unique<-eq[,c( colnames(eq.unique.temp))]
  zeros <- rep(0,15)
  results.cr1 <- cbind(t(cbind(t(p.u),t(p.i),t(df$hazard),t(zeros))),eq.unique)
  
  filename.cr1 <- paste("Tables CR/5 bank eqm W-CR WO-CAP 1st N=",n," for ",date," with cr=",omega.cr.aux,".csv", sep="")
  write.csv(results.cr1, file=filename.cr1)  
}
stopCluster(cl)

###########################################################################
### 6.b Check for Multiple Equilibria -- Use ALL results as grid points ###
###########################################################################

#Generate matrix with all results, in order to add previous equilibria as to the grid search
hazard.grid.m.add <- hazard.grid.m
foreach (i=1:length(omega.cr)) %do% {  
  omega.cr.aux <- omega.cr[i]  
  filename.open <- paste("Tables CR/5 bank eqm W-CR WO-CAP 1st N=",n," for ",date," with cr=",omega.cr.aux,".csv", sep="")
  results.pre <- read.csv(filename.open)
  results.pre <- results.pre[1:15,]
  results.pre <- results.pre[,-1]
  results.pre <- matrix(unlist(results.pre), nrow = 15)
  hazard.grid.m.add <- cbind(results.pre,hazard.grid.m.add)
}

hazard.grid.m.add <- unique(hazard.grid.m.add[1:15,],MARGIN=2)


cl<-makeCluster(24)
registerDoSNOW(cl)
# Search for equilibria again, on this larger grid
foreach (i=1:length(kappa.cr)) %do% {  
  kappa.cr.aux <- kappa.cr[i]
  omega.cr.aux <- omega.cr[i]
  writeLines(c(""), "log.txt")
  sink("log.txt", append=TRUE)
  eq <- foreach (i = 1:(n^5),.combine='cbind',.packages=c("nleqslv"),.errorhandling=c('remove'))  %dopar% {
    cat(paste("Starting iteration",i,"\n"),file="log.txt", append=TRUE)
    fn.findEq((hazard.grid.m.add[,i]),mu,sd,gamma,delta.u,delta.i,alpha.u,alpha.i,b,M.u,M.i,error.i,error.u,c,outside.u, outside.i,r,cap.i,cap.u,kappa.cr.aux,r,t_d,t_r)
  }
  sink()
  colnames(eq) <- colnames(eq, do.NULL = FALSE, prefix = "result.")
  eq.r <- round(eq,2)
  eq.unique.temp<-unique(eq.r[11:15,],MARGIN=2)
  eq.unique<-eq[,c( colnames(eq.unique.temp))]
  zeros <- rep(0,15)
  results.cr2 <- cbind(t(cbind(t(p.u),t(p.i),t(df$hazard),t(zeros))),eq.unique)
  
  # Compute shares
  numer.i.cr2 <- matrix(exp(alpha.i * results.cr2[6:10,] + delta.i + error.i),nrow=5)
  denom.i.cr2 <- colSums(numer.i.cr2) + outside.i
  share.i.cr2 <- t(t(numer.i.cr2) / denom.i.cr2)
  tot.share.i.cr2 <- colSums(share.i.cr2)
  numer.u.cr2 <- matrix(exp(alpha.u * results.cr2[1:5,] + results.cr2[11:15,] * gamma + delta.u + error.u),nrow=5)
  denom.u.cr2 <- colSums(numer.u.cr2) + outside.u
  share.u.cr2 <- t(t(numer.u.cr2) / denom.u.cr2)
  tot.share.u.cr2 <- colSums(share.u.cr2)
  
  #Welfare  
  #CS
  wc.i.cr2 <- matrix((1/alpha.i[1]) * log(colSums(numer.i.cr2)),nrow = 1)
  wc.u.cr2 <- matrix((1/alpha.u[1]) * log(colSums(numer.u.cr2)),nrow = 1)
  wc.tot.cr2 <- (M.i[1] * wc.i.cr2 + M.u[1] * wc.u.cr2)/1000000
  
  #AEV
  r.bar.cr2 <- mu + sd * qnorm(results.cr2[11:15,])
  aev.ind.cr2 <- r[1] * (1+r[1]) * (1+t_r) * (b * (1 - kappa.cr.aux/(1+t_r)) - share.u.cr2 * M.u * (r.bar.cr2 - results.cr2[1:5,] + kappa.cr.aux/(1+t_r)) - share.i.cr2 * M.i * (r.bar.cr2 - c - results.cr2[6:10,] + kappa.cr.aux/(1+t_r)) - kappa.cr.aux * (b + share.u.cr2 * M.u + share.i.cr2 * M.i) * (r.bar.cr2 - r[1]))
  aev.cr2 <- matrix(colSums(aev.ind.cr2)/1000000,nrow = 1)  
  
  #FDIC cost
  fdic.cost.cr2 <- matrix(colSums(M.i*share.i.cr2[1:5,] * results.cr2[11:15,] * (1-0.4))/1000000,nrow = 1)
  
  #Bankruptcy costs
  bc.cost.10.cr2 <- 0.1 * matrix(colSums(results.cr2[11:15,] * (M.i[1] * share.i.cr2[1:5,] + M.u[1] * share.u.cr2[1:5,]))/1000000,nrow = 1)
  bc.cost.20.cr2 <- 0.2 * matrix(colSums(results.cr2[11:15,] * (M.i[1] * share.i.cr2[1:5,] + M.u[1] * share.u.cr2[1:5,]))/1000000,nrow = 1)
  
  #Totals
  w.00.cr2 <- wc.tot.cr2 + aev.cr2 - fdic.cost.cr2                  - (wc.tot.cr2[1,1] + aev.cr2[1,1] - fdic.cost.cr2[1,1])
  w.10.cr2 <- wc.tot.cr2 + aev.cr2 - fdic.cost.cr2 - bc.cost.10.cr2 - (wc.tot.cr2[1,1] + aev.cr2[1,1] - fdic.cost.cr2[1,1] - bc.cost.10.cr2[1,1])
  w.20.cr2 <- wc.tot.cr2 + aev.cr2 - fdic.cost.cr2 - bc.cost.20.cr2 - (wc.tot.cr2[1,1] + aev.cr2[1,1] - fdic.cost.cr2[1,1] - bc.cost.20.cr2[1,1])
  
  #Prepare output
  results.s.cr2 <- rbind(results.cr2[6:10,],results.cr2[1:5,],results.cr2[11:15,],share.i.cr2,tot.share.i.cr2,share.u.cr2,tot.share.u.cr2,wc.tot.cr2,aev.cr2,fdic.cost.cr2,bc.cost.10.cr2,bc.cost.20.cr2,w.00.cr2,w.10.cr2,w.20.cr2)
  rownames(results.s.cr2) <- c("ins_rate_JPM",  "ins_rate_BOA",  "ins_rate_Wells",  "ins_rate_Citi",  "ins_rate_Wach",  "unins_rate_JPM",  "unins_rate_BOA",  "unins_rate_Wells",	"unins_rate_Citi",	"unins_rate_Wach",	"default_prob_JPM",	"default_prob_BOA",	"default_prob_Wells",	"default_prob_Citi",	"default_prob_Wach",	"ins_share_JPM",	"ins_share_BOA",	"ins_share_Wells",	"ins_share_Citi",	"ins_share_Wach",	"ins_share_Cumulative",	"unins_share_JPM",	"unins_share_BOA",	"unins_share_Wells",	"unins_share_Citi",	"unins_share_Wach",	"unins_share_Cumulative","wc_tot","aev","fdic_ins_cost","bc_cost_10","bc_cost_20","w_00","w_10","w_20")
  results.s.cr2.t <- t(results.s.cr2)
  t.cr2 <- data.frame(results.s.cr2.t)
  t1.cr2 <- t.cr2[1,]
  t2.cr2 <- t.cr2[-1,]
  t2.cr2 <- t2.cr2[ order(-t2.cr2$w_00), ]
  t3.cr2 <- rbind(t1.cr2,t2.cr2)
  results.table.cr2 <- t(t3.cr2)
  
  #Output file
  filename.cr2 <- paste("Tables CR/5 bank eqm W-CR WO-CAP 2nd N=",n," for ",date," with cr=",omega.cr.aux,".csv", sep="")
  write.csv(results.table.cr2, file=filename.cr2)
}
stopCluster(cl)
