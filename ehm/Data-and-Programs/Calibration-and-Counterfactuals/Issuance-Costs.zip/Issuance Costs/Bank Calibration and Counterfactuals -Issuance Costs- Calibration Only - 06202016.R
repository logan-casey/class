##############################################################################
##############################################################################
######                                                                  ######
######            Deposit Compeition and Financial Fragility            ###### 
######                  Calibrate Model: EA (Iss) TBTF CR               ######
######                          06/20/2016                              ######
######           By Mark Egan, Ali Hortacsu and Gregor Matvos           ######
######                                                                  ######
##############################################################################
##############################################################################

### Contents ###
# 1. Load files and data 
# 2. Calibrate the model for the full dataset

##############################################################################1

######################################
####    1. Load Files and Data    ####
######################################

#######################
### 1(a) Load Files ###
#######################

.libPaths( c( .libPaths(), "H:/Rpackages") )
library(doSNOW)
library(foreach)
library(nleqslv)
rm(list = ls())
setwd("H:/My Documents/Research/Deposit Competition/R - Files/AER Version/Issuance Costs")
date<- "31mar2008"
df.full<- read.csv("H:/My Documents/Research/Deposit Competition/R - Files/calibration params final.csv")
#df.full$cap.i<- df.full$cmt1y+.05
df.full$cap.i<- 100
df.full$cap.u<- 100
df<-df.full[df.full$date==date& (!is.na(df.full$b)),]
tbtf<- 0.0
df$hazard<- df$hazard/(1-tbtf)
######################
### 1(b) Prep Data ###
######################
#df<-df[df$unins_share>0.03,]
t_d <-0.00
t_r<- 0.05
df$kappa<- df$eq_ratio*0 
df$o_unins_share<- 1-sum(df$unins_share)
df$o_ins_share<- 1-sum(df$ins_share)
p.i<- df$ins_rate
p.u<- df$unins_rate
gamma<- df$gamma*(1-tbtf)
delta.u<-df$delta_u
delta.i<-df$delta_i
alpha.u<-df$alpha_unins
alpha.i<-df$alpha_ins
hazard<-df$hazard
#This calculates the unobserved error term from the demand regression that gives us the observed market share
error.u<- log(df$unins_share)-log(df$o_unins_share[1])-(alpha.u*p.u+delta.u+hazard*gamma)
error.i<- log(df$ins_share)-log(df$o_ins_share[1])-(alpha.i*p.i+delta.i)
outside.u<- (1/df$o_unins_share[1]-sum(exp(alpha.u*p.u+delta.u+hazard*gamma+error.u)))
outside.i<- (1/df$o_ins_share[1]-sum(exp(alpha.i*p.i+delta.i+error.i)))
r<-df$int_rate
r.eq<-r
kappa<-df$kappa
M.u<- df$M_u
M.i<- df$M_i
b<-df$b
cap.i<- df$cap.i[1]
cap.u<- df$cap.u[1]

##############################################################################1

######################################
####    2. Calibrate the Model    ####
######################################

############################################
### 2(a) Function to Calibrate the Model ###
############################################
fn.calib <-function(params,p.u,p.i,hazard,gamma,delta.u,delta.i,alpha.u,alpha.i,b,M.u,M.i,error.i,error.u,outside.u, outside.i,r,cap.i,cap.u,k,r.eq,t_d,t_r){
  mu <- params[1:13]
  sd <- params[14:26]
  c<-params[27:39]
  numer.u<-exp(alpha.u*p.u+delta.u+hazard*gamma+error.u)
  denom.u<- sum(numer.u)+outside.u
  s.u<- numer.u/denom.u
  numer.i<-exp(alpha.i*p.i+delta.i +error.i)
  denom.i<- sum(numer.i)+outside.i
  s.i<- numer.i/denom.i
  r.bar<- qnorm(hazard)*sd+mu
  r.bar.n<- qnorm(hazard)
  r.star.n<- ((b+s.u*M.u*p.u+s.i*M.i*(p.i+c)+r.eq*k*(s.u*M.u+s.i*M.i+b))/((s.u*M.u+s.i*M.i)*(1+k)+b*k)-mu)/sd
  eq.u<- (1+t_r)*alpha.u*(1-s.u)*(mu*(1+k)-p.u-r.eq*k+(1+k)*sd*dnorm(r.bar.n)/(1-pnorm(r.bar.n)))*(1-pnorm(r.bar.n))-(1+t_r)*(1-pnorm(r.bar.n))+(1-t_d)*alpha.u*(1-s.u)*((1+k)*mu-p.u-r.eq*k+(1+k)*sd*dnorm(r.star.n)/(1-pnorm(r.star.n)))*(1-pnorm(r.star.n))-(1-t_d)*(1-pnorm(r.star.n))-(1+t_r)*alpha.u*(1-s.u)*((1+k)*mu-p.u-r.eq*k+(1+k)*sd*dnorm(r.star.n)/(1-pnorm(r.star.n)))*(1-pnorm(r.star.n))+(1+t_r)*(1-pnorm(r.star.n))-k*alpha.u*(1-s.u)*pnorm(r.bar.n)
  eq.i<- (1+t_r)*alpha.i*(1-s.i)*(mu*(1+k)-p.i-c-r.eq*k+(1+k)*sd*dnorm(r.bar.n)/(1-pnorm(r.bar.n)))*(1-pnorm(r.bar.n))-(1+t_r)*(1-pnorm(r.bar.n))+(1-t_d)*alpha.i*(1-s.i)*((1+k)*mu-p.i-c-r.eq*k+(1+k)*sd*dnorm(r.star.n)/(1-pnorm(r.star.n)))*(1-pnorm(r.star.n))-(1-t_d)*(1-pnorm(r.star.n))-(1+t_r)*alpha.i*(1-s.i)*((1+k)*mu-p.i-c-r.eq*k+(1+k)*sd*dnorm(r.star.n)/(1-pnorm(r.star.n)))*(1-pnorm(r.star.n))+(1+t_r)*(1-pnorm(r.star.n))-k*alpha.i*(1-s.i)*pnorm(r.bar.n)
  lhs<-((1+t_r)*(1+r)/(s.u*M.u+M.i*s.i+b))*(b*(1-k/(1+t_r))-s.u*M.u*(r.bar-p.u+k/(1+t_r))-s.i*M.i*(r.bar-c-p.i+k/(1+t_r))-k*(s.u*M.u+s.i*M.i+b)*(r.bar-r.eq)) 
  rhs<- -k +(k+(s.u*M.u+M.i*s.i)/(s.u*M.u+M.i*s.i+b))*(1+t_r)*((mu-r.bar)*(pnorm(r.star.n)-pnorm(r.bar.n))+sd*dnorm(r.bar.n)-sd*dnorm(r.star.n))+(k+(s.u*M.u+M.i*s.i)/(s.u*M.u+M.i*s.i+b))*(1-t_d)*((mu-r.bar)*(1-pnorm(r.star.n))+sd*dnorm(r.star.n))
  eq.haz<- lhs-rhs 
  res<- cbind(t(eq.u),t(eq.i),matrix(eq.haz,ncol=13,nrow=1))
  return(res)
}
########################
### 2(b) Calibration ###
########################
params<-c(df$mu,df$sd,df$c)
fn.calib(params,p.u,p.i,hazard,gamma,delta.u,delta.i,alpha.u,alpha.i,b,M.u,M.i,error.i,error.u,outside.u, outside.i,r,cap.i,cap.u,kappa,r.eq,t_d,t_r)
find.eq<- nleqslv(params,fn.calib,control=list(maxit=5000,ftol=1e-12, xtol=1e-12),p.u=p.u,p.i=p.i,hazard=hazard,gamma=gamma,delta.u=delta.u,delta.i=delta.i,alpha.u=alpha.u,alpha.i=alpha.i,b=b,M.u=M.u,M.i=M.i,error.i=error.i,error.u=error.u,outside.u=outside.u,outside.i=outside.i,r=r,cap.i=cap.i,cap.u=cap.u,k=kappa,r.eq=r.eq,t_d=t_d,t_r=t_r)    
params<-find.eq$x
find.eq<- nleqslv(params,fn.calib,control=list(maxit=5000,ftol=1e-12, xtol=1e-12),p.u=p.u,p.i=p.i,hazard=hazard,gamma=gamma,delta.u=delta.u,delta.i=delta.i,alpha.u=alpha.u,alpha.i=alpha.i,b=b,M.u=M.u,M.i=M.i,error.i=error.i,error.u=error.u,outside.u=outside.u,outside.i=outside.i,r=r,cap.i=cap.i,cap.u=cap.u,k=kappa,r.eq=r.eq,t_d=t_d,t_r=t_r)    

mu<- find.eq$x[1:13]
sd<- find.eq$x[14:26]
c<- find.eq$x[27:39]
df$mu<-mu
df$sd<-sd
df$c<-c 

